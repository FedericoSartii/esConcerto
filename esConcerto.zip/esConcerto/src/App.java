import java.util.ArrayList;
import java.util.List;

public class App {
    public static void main(String[] args) {
        List<Venditore> ventitori = new ArrayList<Venditore>();
        for (int i = 0; i < 3; i++)
            ventitori.add(new Venditore("Venditore " + (i+1)));

        Botteghino botteghino = new Botteghino(ventitori);

        List<Compratore> compratori = new ArrayList<Compratore>();
        for (int i = 0; i < 30; i++)
            compratori.add(new Compratore("Compratore " + (i+1), botteghino));

        for(Venditore v : ventitori)
            v.start();
        for(Compratore c : compratori)
            c.start();

        try {
            Thread.sleep(10000);
        } catch (InterruptedException ignoreException) {}

        int rand = (int) (Math.random() * 30);
        compratori.get(rand).restituisciBiglietto(compratori.get(rand));
        
        try {
            Thread.sleep(5000);
        } catch (InterruptedException ignoreException) {}
        for(Venditore v : ventitori)
            v.interrupt();
        for(Compratore c : compratori)
            c.interrupt();
        System.exit(0);
    }
}
